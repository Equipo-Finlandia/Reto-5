var sesion=localStorage.getItem('sesion');

window.onload=function(){
	console.log("ventana cargado");
	var formacion = document.getElementById("formacion");
	var acceder = document.getElementById("acceder");
	var colegiacion = document.getElementById("colegiacion");
	
    console.log(this.sesion);
    if (this.sesion==null || this.sesion=='0'){
        console.log("no hay sesion");
        formacion.style.display= 'none';
        colegiacion.style.display= 'none';
    	acceder.style.display= 'block';
    }
	if(this.sesion=='1'){
    	console.log("sesion correcto");
        formacion.style.display= 'block';
        colegiacion.style.display= 'block';
    	acceder.style.display= 'none';
    }
}

function sesionCorrecto(){
	this.sesion='1';
    localStorage.setItem('sesion','1');
    console.log(this.sesion);
}
